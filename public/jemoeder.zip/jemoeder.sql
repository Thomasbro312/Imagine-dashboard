-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Versie:              12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Structuur van  tabel apitest.apikeys wordt geschreven
CREATE TABLE IF NOT EXISTS `apikeys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `api_key` varchar(50) NOT NULL DEFAULT '0',
  `user_id` int DEFAULT NULL,
  `redirect` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '''false''',
  PRIMARY KEY (`id`),
  KEY `user_api` (`user_id`),
  CONSTRAINT `user_api` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumpen data van tabel apitest.apikeys: ~1 rows (ongeveer)
INSERT INTO `apikeys` (`id`, `api_key`, `user_id`, `redirect`) VALUES
	(1, 'KAas', 70, NULL);

-- Structuur van  tabel apitest.apikeysgroup wordt geschreven
CREATE TABLE IF NOT EXISTS `apikeysgroup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_api_key` int NOT NULL,
  `component_name` varchar(255) NOT NULL DEFAULT '',
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_api_key` (`id_api_key`),
  KEY `FK_user_id` (`user_id`),
  CONSTRAINT `FK_api_key` FOREIGN KEY (`id_api_key`) REFERENCES `apikeys` (`id`),
  CONSTRAINT `FK_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumpen data van tabel apitest.apikeysgroup: ~0 rows (ongeveer)

-- Structuur van  tabel apitest.campaigns wordt geschreven
CREATE TABLE IF NOT EXISTS `campaigns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `campaign_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `campaign_phase` int DEFAULT NULL,
  `diff_date` int DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_client` (`client_id`) USING BTREE,
  KEY `FK_phase` (`campaign_phase`),
  CONSTRAINT `FK_client` FOREIGN KEY (`client_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FK_phase` FOREIGN KEY (`campaign_phase`) REFERENCES `phasestatus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumpen data van tabel apitest.campaigns: ~9 rows (ongeveer)
INSERT INTO `campaigns` (`id`, `campaign_id`, `campaign_name`, `client_id`, `start_date`, `end_date`, `campaign_phase`, `diff_date`) VALUES
	(19, 'imagine_campaign_9427472', 'New New Campaign', 71, '2023-10-31 23:00:00', '2024-02-13 23:00:00', 2, 105),
	(21, 'imagine_campaign_7869935', 'The Best Campaign', 72, '2024-01-03 23:00:00', '2024-01-24 23:00:00', 3, 21),
	(22, 'imagine_campaign_9428374', 'Coolest Campaign on the world', 70, '2023-11-03 23:00:00', '2024-01-28 23:00:00', 1, 86),
	(23, 'imagine_campaign_1222732', 'New New Campaign', 72, '2023-10-25 22:00:00', '2023-11-08 23:00:00', 1, 14),
	(24, 'imagine_campaign_1587681', 'New New Campaign', 71, '2023-11-22 23:00:00', '2023-11-02 23:00:00', 1, 20),
	(25, 'imagine_campaign_3832793', 'Cool', 71, '2023-11-21 23:00:00', '2023-11-28 23:00:00', 1, 7),
	(26, 'imagine_campaign_9420709', 'Cool', 71, '2023-11-21 23:00:00', '2023-11-28 23:00:00', 1, 7),
	(27, 'imagine_campaign_8289838', 'Coolest Campaign on the world', 72, '2023-11-27 23:00:00', '2023-12-27 23:00:00', 1, 30),
	(28, 'imagine_campaign_3018476', 'Cool', 71, '2023-12-11 23:00:00', '2024-01-16 23:00:00', 1, 36),
	(29, 'imagine_campaign_2539546', 'Coolest Campaign on the world', 70, '2023-11-21 23:00:00', '2024-01-04 23:00:00', 1, 44);

-- Structuur van  tabel apitest.domainlog wordt geschreven
CREATE TABLE IF NOT EXISTS `domainlog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(50) NOT NULL DEFAULT '',
  `session_id` text NOT NULL,
  `page_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `device` varchar(50) NOT NULL DEFAULT '',
  `device_os` varchar(50) NOT NULL DEFAULT '',
  `device_browser` varchar(50) NOT NULL DEFAULT '',
  `datetimestamp` timestamp NOT NULL,
  `campaign_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_domainlog_campaigns` (`campaign_id`),
  CONSTRAINT `FK_domainlog_campaigns` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumpen data van tabel apitest.domainlog: ~122 rows (ongeveer)
INSERT INTO `domainlog` (`id`, `domain_name`, `session_id`, `page_name`, `device`, `device_os`, `device_browser`, `datetimestamp`, `campaign_id`) VALUES
	(1, 'oesterdam.nl', '79465132', '/', 'mobile', 'Android', 'Chrome', '2023-11-09 23:00:00', 22),
	(2, 'oesterdam.nl', '87756413', '/help', 'desktop', 'Windows', 'Chrome', '2023-11-17 09:14:18', 22),
	(3, 'oesterdam.nl', '78945612', '/home', 'mobile', 'IOS', 'Safari', '2023-11-16 09:22:09', 22),
	(4, 'oesterdam.nl', '874561231', '/home', 'deskptop', 'sdadsa', 'dasdasd', '2023-12-17 13:20:31', 22),
	(5, 'Array', '/test', '4739410', 'Google Chrome', 'Windows', '', '2023-11-20 09:25:55', 22),
	(6, 'Array', '/test', '6269908', 'Google Chrome', 'Windows', '', '2023-11-20 09:25:58', 22),
	(7, 'Array', '/test', '1193661', 'Google Chrome', 'Windows', '', '2023-11-20 09:25:59', 22),
	(8, 'Array', '/test', '1983055', 'Google Chrome', 'Windows', '', '2023-11-20 09:25:59', 22),
	(9, 'Array', '/test', '9286279', 'Google Chrome', 'Windows', '', '2023-11-20 09:25:59', 22),
	(10, 'Array', '/test', '7319533', 'Google Chrome', 'Windows', '', '2023-11-20 09:26:00', 22),
	(11, 'Array', '/test', '2988696', '', 'Windows', '', '2023-11-20 09:26:42', 22),
	(12, 'Array', '/test', '9693602', '', 'Windows', 'Google Chrome', '2023-11-20 09:29:27', 22),
	(13, 'Array', '/test', '8285812', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:40', 22),
	(14, 'Array', '/test', '4359886', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:55', 22),
	(15, 'Array', '/test', '5636673', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:55', 22),
	(16, 'Array', '/test', '2020961', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:56', 22),
	(17, 'Array', '/test', '4659310', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:57', 22),
	(18, 'Array', '/test', '8074862', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:57', 22),
	(19, 'Array', '/test', '9095807', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:57', 22),
	(20, 'Array', '/test', '8968878', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:58', 22),
	(21, 'Array', '/test', '2765154', '', 'Windows', 'Google Chrome', '2023-11-20 09:41:58', 22),
	(22, 'Array', '/test', '9268491', '', 'Windows', 'Google Chrome', '2023-11-20 09:42:46', 22),
	(23, 'Array', '/test', '5419704', '', 'Windows', 'Google Chrome', '2023-11-20 09:54:39', 22),
	(24, 'Array', '/test', '3844601', '', 'Windows', 'Google Chrome', '2023-11-20 09:54:40', 22),
	(25, 'Array', '/test', '1345013', '', 'Windows', 'Google Chrome', '2023-11-20 09:54:40', 22),
	(26, 'Array', '/test', '3455099', '', 'Windows', 'Google Chrome', '2023-11-20 09:54:41', 22),
	(27, 'Array', '/test', '3359448', '', 'Windows', 'Google Chrome', '2023-11-20 09:54:41', 22),
	(28, 'Array', '/test', '5214467', '', 'Windows', 'Google Chrome', '2023-11-20 09:54:42', 22),
	(29, 'Array', '/test', '5903773', '', 'Windows', 'Google Chrome', '2023-11-20 09:57:43', 22),
	(30, 'Array', '/test', '4588529', 'mobile', 'Windows', 'Google Chrome', '2023-11-20 10:04:32', 22),
	(31, 'Array', '/test', '1035115', 'mobile', 'Windows', 'Google Chrome', '2023-11-20 10:04:35', 22),
	(32, 'Array', '/test', '4094680', 'mobile', 'Windows', 'Google Chrome', '2023-11-20 10:04:36', 22),
	(33, 'Array', '/test', '2213705', 'mobile', 'Windows', 'Google Chrome', '2023-11-20 10:04:36', 22),
	(34, 'Array', '/test', '2508043', 'mobile', 'Windows', 'Google Chrome', '2023-11-20 10:04:36', 22),
	(35, 'Array', '/test', '4244259', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:04:58', 22),
	(36, 'Array', '/test', '6426528', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:05:03', 22),
	(37, 'Array', '/test', '4959383', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:05:03', 22),
	(38, 'Array', '/test', '6313855', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:05:04', 22),
	(39, 'Array', '/test', '3626533', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:05:04', 22),
	(40, 'Array', '/test', '3351432', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:16:13', 22),
	(41, 'Array', '/test', '1448303', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:16:21', 22),
	(42, 'Array', '/test', '6359964', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:16:42', 22),
	(43, '127.0.0.1', '/test', '8083883', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:16:54', 22),
	(44, '127.0.0.1', '/test', '3331689', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 10:17:01', 22),
	(45, '127.0.0.1', '/test', '4396971', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:45:46', 22),
	(46, '127.0.0.1', '/test', '2628597', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:45:58', 22),
	(47, '127.0.0.1', '/test', '4328471', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:11', 22),
	(48, '127.0.0.1', '/test', '5683319', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:12', 22),
	(49, '127.0.0.1', '/test', '5186417', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:12', 22),
	(50, '127.0.0.1', '/test', '5076633', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:13', 22),
	(51, '127.0.0.1', '/test', '4269270', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:13', 22),
	(52, '127.0.0.1', '/test', '6007946', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:13', 22),
	(53, '127.0.0.1', '/test', '7495055', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:15', 22),
	(54, '127.0.0.1', '/test', '4287624', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:15', 22),
	(55, '127.0.0.1', '/test', '8767167', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:16', 22),
	(56, '127.0.0.1', '/test', '6045047', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:16', 22),
	(57, '127.0.0.1', '/test', '6042516', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:17', 22),
	(58, '127.0.0.1', '/test', '7552925', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:18', 22),
	(59, '127.0.0.1', '/test', '8879599', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:18', 22),
	(60, '127.0.0.1', '/test', '5096097', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:48:19', 22),
	(61, '127.0.0.1', '/test', '4610338', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 13:53:51', 22),
	(62, '127.0.0.1', '/test', '9607832', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:21', 22),
	(63, '127.0.0.1', '/test', '3194893', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:23', 22),
	(64, '127.0.0.1', '/test', '6744666', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:24', 22),
	(65, '127.0.0.1', '/test', '1644921', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:25', 22),
	(66, '127.0.0.1', '/test', '6097351', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:25', 22),
	(67, '127.0.0.1', '/test', '3251101', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:26', 22),
	(68, '127.0.0.1', '/test', '3103309', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:26', 22),
	(69, '127.0.0.1', '/test', '9267769', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:26', 22),
	(70, '127.0.0.1', '/test', '5654291', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:27', 22),
	(71, '127.0.0.1', '/test', '2031341', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:28', 22),
	(72, '127.0.0.1', '/test', '5371634', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:28', 22),
	(73, '127.0.0.1', '/test', '7238074', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:28', 22),
	(74, '127.0.0.1', '/test', '4814829', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:29', 22),
	(75, '127.0.0.1', '/test', '9951027', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:29', 22),
	(76, '127.0.0.1', '/test', '5958236', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:30', 22),
	(77, '127.0.0.1', '/test', '6697106', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:30', 22),
	(78, '127.0.0.1', '/test', '5993922', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:31', 22),
	(79, '127.0.0.1', '/test', '1946368', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:31', 22),
	(80, '127.0.0.1', '/test', '9480503', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:32', 22),
	(81, '127.0.0.1', '/test', '3869628', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:32', 22),
	(82, '127.0.0.1', '/test', '1420783', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:33', 22),
	(83, '127.0.0.1', '/test', '7489440', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:33', 22),
	(84, '127.0.0.1', '/test', '4998508', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:34', 22),
	(85, '127.0.0.1', '/test', '8145076', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:34', 22),
	(86, '127.0.0.1', '/test', '3410640', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:35', 22),
	(87, '127.0.0.1', '/test', '8683470', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:35', 22),
	(88, '127.0.0.1', '/test', '8231798', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:35', 22),
	(89, '127.0.0.1', '/test', '7750258', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:36', 22),
	(90, '127.0.0.1', '/test', '7170975', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:36', 22),
	(91, '127.0.0.1', '/test', '2699824', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:09:37', 22),
	(92, '127.0.0.1', '/test', '1218179', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:31:50', 22),
	(93, '127.0.0.1', '/test', '4367054', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:31:52', 22),
	(94, '127.0.0.1', '/test', '7830510', 'desktop', 'Windows', 'Google Chrome', '2023-11-20 14:31:53', 22),
	(95, '127.0.0.1', '/test', '6436578', 'desktop', 'Windows', 'Google Chrome', '2023-11-21 07:13:51', 22),
	(96, '127.0.0.1', '/test', '3350226', 'desktop', 'Windows', 'Google Chrome', '2023-11-21 07:23:43', 22),
	(97, '127.0.0.1', '/test', '4659501', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:22', 22),
	(98, '127.0.0.1', '/test', '5937376', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:25', 22),
	(99, '127.0.0.1', '/test', '8304203', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:26', 22),
	(100, '127.0.0.1', '/test', '3108545', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:27', 22),
	(101, '127.0.0.1', '/test', '1960781', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:28', 22),
	(102, '127.0.0.1', '/test', '3050540', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:29', 22),
	(103, '127.0.0.1', '/test', '3500532', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:31', 22),
	(104, '127.0.0.1', '/test', '7036651', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:32', 22),
	(105, '127.0.0.1', '/test', '5743626', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:33', 22),
	(106, '127.0.0.1', '/test', '2952261', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:47', 22),
	(107, '127.0.0.1', '/test', '8456314', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:47', 22),
	(108, '127.0.0.1', '/test', '4525728', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:48', 22),
	(109, '127.0.0.1', '/test', '8334003', 'desktop', 'Windows', 'Google Chrome', '2023-11-22 13:24:48', 22),
	(110, '127.0.0.1', '/test', '9500235', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:37', 22),
	(111, '127.0.0.1', '/test', '4444422', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:37', 22),
	(112, '127.0.0.1', '/test', '3251241', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:37', 22),
	(113, '127.0.0.1', '/test', '3507118', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:38', 22),
	(114, '127.0.0.1', '/test', '8959016', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:38', 22),
	(115, '127.0.0.1', '/test', '9023576', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:38', 22),
	(116, '127.0.0.1', '/test', '8552571', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:38', 22),
	(117, '127.0.0.1', '/test', '3110161', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:38', 22),
	(118, '127.0.0.1', '/test', '4822301', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:39', 22),
	(119, '127.0.0.1', '/test', '1986284', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:39', 22),
	(120, '127.0.0.1', '/test', '8983695', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:39', 22),
	(121, '127.0.0.1', '/test', '4179058', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:39', 22),
	(122, '127.0.0.1', '/test', '5412407', 'desktop', 'Windows', 'Google Chrome', '2023-11-24 09:05:39', 22);

-- Structuur van  tabel apitest.phasestatus wordt geschreven
CREATE TABLE IF NOT EXISTS `phasestatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phase_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumpen data van tabel apitest.phasestatus: ~3 rows (ongeveer)
INSERT INTO `phasestatus` (`id`, `phase_name`) VALUES
	(1, 'Planning'),
	(2, 'Doing'),
	(3, 'Done');

-- Structuur van  tabel apitest.users wordt geschreven
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `phone_number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `role` int DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumpen data van tabel apitest.users: ~4 rows (ongeveer)
INSERT INTO `users` (`user_id`, `email`, `phone_number`, `company_name`, `password`, `user_name`, `role`) VALUES
	(70, 'thomasbro312@gmail.com', '0681229769', 'Vroom', '$2y$10$KhTEiZjKO2mpSAY.0sUmv.VhIOdnlo3yjyBPJP5xmJpjv.h09iBky', 'Thomas Brocatus', 2),
	(71, 'test@test.nl', '0681229769', 'Devbyte', '$2y$10$wBjhoi1i3dqFk9Ts9h5rWeUuZ6CFsXTwiOzW/8oexmiuHJIcdE0Yi', 'Pieter', 1),
	(72, 'jesus@help.com', '0681229769', 'Subishi', '$2y$10$OMEDAuVJ0b9ll9h/blkdveMdBNE1GUxbuzm259tvXIeUY8XnoEwLW', 'Help Man', 1),
	(73, 'tst@gmail.com', '', '', '$2y$10$QM4jsPXBtaMEkj75SannAOLQirqiFdseF5i1Es7L0s9tBwg1.7J9O', 'Thomas Brocatus', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
